<?php
include_once './Clase/divicion/Divicion1.php';

$objEmployee = new Employee(12,4);

echo $objEmployee->getDivicionFrist(); //resultado de la Multiplicacion

?>