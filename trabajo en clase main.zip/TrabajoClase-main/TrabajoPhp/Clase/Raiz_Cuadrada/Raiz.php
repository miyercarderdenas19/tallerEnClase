<?php
$numero = 25;
$raizCuadrada = sqrt($numero);

echo "La raíz cuadrada de $numero es: $raizCuadrada";
?>