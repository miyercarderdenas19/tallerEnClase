<?php
echo "<hr>";
echo "<h1 style='text-aling: center'>Menu Inicio</h1> ";
echo "<hr>";
echo"<ul>
<li>
 <a>
 Suma
 </a>
</li>
<li>
  <a>
   Resta
   </a>
</li>
<li>
 <a>
 multiplicacion
 </a>
</li>
<li>
 <a>
 divicion
 </a>
</li>
<li>
  <a>
 Parrafo
 </a>
</li>
</ul>";
