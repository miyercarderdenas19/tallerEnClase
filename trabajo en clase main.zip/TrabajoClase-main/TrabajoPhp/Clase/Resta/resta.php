<?php
include_once './Clase/Resta2.php';

$objEmployee = new Employee(24,4);

echo $objEmployee->getRestaFrist(); //resultado de la suma

?>