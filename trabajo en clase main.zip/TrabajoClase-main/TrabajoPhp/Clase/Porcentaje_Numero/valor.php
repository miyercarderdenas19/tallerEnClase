<?php
include_once './Clase/multiplicacion/multiplicacion.php';

$objEmployee = new Employee(200,30);

echo $objEmployee->getPorcentajeFrist(); //resultado de la Multiplicacion

?>