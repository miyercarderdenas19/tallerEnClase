<?php
include_once './Clase/multiplicacion/multiplicacion.php';

$objEmployee = new Employee(12,4);

echo $objEmployee->getMultiFrist(); //resultado de la Multiplicacion

?>