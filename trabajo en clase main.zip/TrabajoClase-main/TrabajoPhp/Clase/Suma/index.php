<?php
include_once './Clase/procesar.php';

$objEmployee = new Employee(12,4);

echo $objEmployee->getSumaFrist(); //resultado de la suma

?>