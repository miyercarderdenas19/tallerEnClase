<?php
echo "<hr>";
echo " <h2 style='text-aling: center'>Parrafo</h2> ";
echo "<hr>";
//declaracion de variables 
$Parrafo1 = '';
$Parrafo2 ='';
$Parrafo3 ='';
$Parrafo4 ='';
$Parrafo5 ='';
$Parrafo6 ='';

$ParrafoCompleto ='';
//procsamietnos de datos
$Parrafo1 ='Eran las últimas horas de la tarde, de un día nublado, de un año de esos en que la temporada ciclónica
 se hace activa y violenta. La isla de Cuba, enclavada en la boca del golfo de México, hace malabares por tratar de
 esquivar cada año a los huracanes, que por costumbre, han tomado este camino del Caribe, como sendero para llegar a
 casa, desde hace mucho, desde siempre.';
$Parrafo2 ='Norberto, joven campesino había terminado su jornada laboral en su finca, mientras aprovechaba los últimos
 rayos de sol para dejar a sus animales alimentados, el caballo con su paca de cogollo de la dulce gramínea, los pollos y
 gallinas revoletean en el corral persiguiendo cada puñado de maíz rallado que Norberto les lanza. Los patos con más alcurnia
 y lentitud, siempre llegan después de las gallinas y los pollos, el gallo, como el rey del patio, simula que no le interesa la
 comida y lanza un fuerte quiquiriquí. En la cochiquera, los dos cerdos de Norberto, esperan bulliciosos por la preciada ración vespertina,
 un manjar preparado de miel con paja de arroz, adornado con plátanos verdes, troceados, como sabrosos pedazos de un chorizo 
 verde y natural.';
 
$Parrafo3 ='En la cocina del bohío, se huele un rico aroma a café recién colado, su esposa, le acerca el sabroso líquido humeante, en una 
güirita recortada, que Norberto usa como taza, dice que en la güira el café le sabe mejor. Mientras se recuesta en la pared con
 su taburete hecho de madera dura y cuero de buey, prende la radio, y escucha la fatal noticia. Un huracán categoría cuatro se 
 acerca a su terruño, y por la magnitud que trae, todo tendrá que ser evacuado, mira al cielo, ve a las auras volar en círculos
 desorientadas, los pájaros vuelan a gran velocidad huyendo del mal que se aproxima, y Norberto ya de pié, se vuelve a colocar 
 su camisa sudada, para comenzar la jornada más importante de su vida. Proteger sus bienes y a su familia, en el baraentierra
 preparado.';
 
 $Parrafo4 ='El hotel del centro es el más antiguo del pueblo y también es aquel que tiene más comodidades. 
 Este hotel fue construido en 1911, pero primero se utilizó como casa de familia. En 1975 un inversionista 
 compró esta propiedad y la reformó para transformarla en el hotel que hoy conocemos. Es un hotel pequeño, pero 
 cuenta con servicio a la habitación, con pileta climatizada, con un restaurante de categoría, entre otras cosas';
 
 $Parrafo5 ='La famosa banda de rock se separó, al menos por un tiempo. Los integrantes declararon en diversos medios 
 que no hubo una pelea, sino que quieren trabajar un tiempo como solitas. Además, en una rueda de prensa,
 el representante dijo que es probable que el año próximo los músicos se vuelvan a juntar para hacer una gira.
 
 Muchas personas creen que los osos polares están en peligro de extinción, pero la denominación correcta sobre la
 situación de esta especie es que están en situación de conservación vulnerable. De todas formas, es necesario que 
 se actúe rápidamente para evitar que esta especie desaparezca.
 
 Las religiones pueden ser monoteístas o politeístas. Las monoteístas son religiones que creen en la existencia de un
 único dios, por ejemplo, el cristianismo. En cambio, en las religiones politeístas se cree en la existencia de muchos 
 dioses, por ejemplo, el sintoísmo japonés.';
 
 $Parrafo6='Este sábado se jugará la final del torneo de fútbol. Este evento es muy importante para los deportistas y para los fanáticos, porque se decidirá qué equipo es el campeón nacional de este año. 
 Es muy difícil hacer un pronóstico del resultado, porque ambos equipos tienen muy buenos jugadores.
Los especialistas recomiendan que haya un buen sistema de comunicación empresarial para que una compañía esté bien organizada.
 Establecer un buen sistema de comunicación es fundamental para mejorar la productividad, intercambiar opiniones y resolver inconvenientes.
Existen tres modos verbales: indicativo, subjuntivo e imperativo. El modo indicativo se utiliza para narrar hechos, procesos o 
estados que se consideran reales. El modo subjuntivo se utiliza para expresar sentimientos, pensamientos, emociones, deseos, 
pedidos, dudas y suposiciones. El modo imperativo se utiliza para dar órdenes y consejos.
La actividad del sector turístico ha aumentado considerablemente en la ciudad y esto ha generado muy buenos ingresos para las 
personas que trabajan en este sector. Esta mejora es una consecuencia de que el gobierno haya organizado mejor el circuito 
turístico y de que haya hecho campañas de difusión de los lugares que se pueden visitar.
Los especialistas recomiendan que se mejore el tratamiento de la basura lo antes posible, ya que un buen tratamiento de la 
basura es fundamental para que se reduzca la contaminación. Por eso, es indispensable que se pueda organizar un sistema para 
recuperar los desechos reciclables';
 
$ParrafoCompleto = $Parrafo1. '' .$Parrafo2. ''. $Parrafo3. ''.$Parrafo4.''.$Parrafo5.''.$Parrafo6;

echo$ParrafoCompleto;
?>



